<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Twitter Test Suit </name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4bbf908c-fb21-4c58-a710-1bb0bc176673</testSuiteGuid>
   <testCaseLink>
      <guid>d4072adf-1714-405b-b8a9-2103456fea42</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Twitter Test Suit /Log In Test Case</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>201e147e-6bf7-403b-b907-9d04c6fbad79</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Twitter Test Suit /Search Test Case</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7f095207-3cca-41a5-8b05-8ba9d764cc8a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Twitter Test Suit /Post Test Case</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>0cc305ea-838c-49d6-acd9-123e66b04fd6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Twitter Test Suit /Profile Test Case</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    